from word2 import Word
import pyperclip

class MemoryEditor:
    def __init__(self, uvsim):
        self.uvsim = uvsim

    def insert_val(self, value, position):
        """This is the add command for the gui in Milestone 4"""
        new_word = Word(int(value))
        self.uvsim.memory.insert(position, new_word)

    def delete(self, position):
        """Delete command for the gui in Milestone 4"""
        self.uvsim.memory.pop(position)

    def copy(self, position):
        """Copy for gui. Milestone 4"""
        pyperclip.copy(str(self.uvsim.memory[position].value))

    def cut(self, position):
        """Cut for gui. Milestone 4"""
        pyperclip.copy(str(self.uvsim.memory[position].value))
        self.delete(position)

    def paste(self, position):
        """Paste for gui. Milestone 4"""
        new_word = Word(int((pyperclip.paste())))
        self.uvsim.memory.insert(position, new_word)

    def read_file(self, filename, memory):
        # iterate through the lines
        with open(filename) as f:
            lines = f.readlines()

            try:
                if len(lines) > 250:
                    raise IndexError("File exceeds memory capacity of 250 lines.")
                
                for i, line in enumerate(lines):
                    memory.memory[i].set_value(int(convert(line)))
            except IndexError:
                return "File exceeds memory capacity of 250 lines."
            
def convert(s):
    """converts string that is 4 digits into 6 digits"""
    if len(s) < 7: # includes sign
        s = s[:3] + ("0" * 2) + s[3:] # needs to be 2 because op codes are two digits
    return s