from word2 import Word
from memory_editor2 import MemoryEditor
from enum import Enum, auto
from tkinter import simpledialog
from memory_commands2 import Read, Write, Load, Store, Add, Subtract, Divide, Multiply, Branch, BranchNeg, BranchZero, Halt, SendError

class Opcode(Enum):
    READ = 10
    WRITE = 11
    LOAD = 20
    STORE = 21
    ADD = 30
    SUBTRACT = 31
    DIVIDE = 32
    MULTIPLY = 33
    BRANCH = 40
    BRANCHNEG = 41
    BRANCHZERO = 42
    HALT = 43

class PerformOperation:
    def __init__(self):
        self.operation = None
    
    def set_command(self, op, memory):
        send_command = None
        match op:
            case "READ":
                send_command = Read(memory)
            case "WRITE":
                send_command = Write(memory)
            case "LOAD":
                send_command = Load(memory)
            case "STORE":
                send_command = Store(memory)
            case "ADD":
                send_command = Add(memory)
            case "SUBTRACT":
                send_command = Subtract(memory)
            case "DIVIDE":
                send_command = Divide(memory)
            case "MULTIPLY":
                send_command = Multiply(memory)
            case "BRANCH": 
                send_command = Branch(memory)
            case "BRANCHNEG":
                send_command = BranchNeg(memory)
            case "BRANCHZERO":
                send_command = BranchZero(memory)
            case "HALT":
                send_command = Halt(memory)
            case _:
                send_command = SendError(memory)

        self.operation = send_command

    def execute(self, word):
        print(word, type(word))
        operand = word.get_value() % 10**4
        if operand > 250:
            raise ValueError("Operand operating on a value greater than 250")
        return self.operation.execute(operand)