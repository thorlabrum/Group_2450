import json
import tkinter as tk
from multiprocessing import Process
from memory import Memory
from memory_commands2 import Read, Write, Store, Add, Subtract, Divide, Multiply, Branch, BranchNeg, BranchZero, Halt, SendError, convert
from memory_editor2 import MemoryEditor
from dynamic_command import DynamicCommand
from perform_operation import PerformOperation
from tkinter import filedialog as fd
from tkinter import messagebox as mb
import customtkinter as ctk


def get_json():
    with open ('placement_values.json', 'r') as file:
        placement = json.load(file)
    return placement


def show_window(window, path):
    '''
    This function is run in a separate process to edit and run the simulator
    '''
    print('being called')
    place = get_json()

    def update_memory():
        contents = ''
        for val in range(len(mem.memory)):
            contents += f'{val}: {mem.memory[val]}\n'
        edit_mem_textbox.delete(1.0, ctk.END)
        edit_mem_textbox.insert(1.0, contents)

    def mem_insert():
        # Read from value and insert into position
        nonlocal mem_editor
        val=int(value_entry.get())
        pos=int(pos_entry.get())
        mem_editor.insert_val(val, pos)
        update_memory()

    def mem_delete():
        # delete position from memory
        nonlocal mem_editor
        pos=int(pos_entry.get())
        mem_editor.delete(pos)
        update_memory()

    def mem_copy():
        # copy value from position into clipboard
        nonlocal mem_editor
        pos=int(pos_entry.get())
        mem_editor.copy(pos)
        update_memory()

    def mem_cut():
        # copy value from position into clipboard and delete from memory
        nonlocal mem_editor
        pos=int(pos_entry.get())
        mem_editor.cut(pos)
        update_memory()

    def mem_paste():
        # paste value from clipboard into position in memory
        nonlocal mem_editor
        pos=int(pos_entry.get())
        mem_editor.paste(pos)
        update_memory()

    def save_memory():
        nonlocal path, mem
        with open(path, 'w') as file:
            file.write(str(mem.memory))   

    def run():
        nonlocal mem
        command = DynamicCommand()
        perform = PerformOperation()
        for word in mem:
            op = command.get_operation(word)
            perform.set_command(op, mem)
            info = perform.execute(word)
            run_results.insert(ctk.END, str(info))

    def edit_help():
        mb.showinfo(title=help,
                    message="""This screen allows you to edit the memory loaded into the memulator before
                    running the simulator. 
                    Insert: Insert the value specified in 'Value' into 'Position'
                    Delete: Delete the value specified in 'Position', remaining values shift
                    Copy: Copy the value in 'Position' to the clipboard
                    Cut: Cut the value in 'Position'
                    Paste: Paste the value from your clipboard into 'Position'
                    Save: Saves the current memory to the same textfile""")
        
    def run_help():
        mb.showinfo(title=help, 
                    message="""This screen runs the memory of UVSim and shows:
                    the list of commands run and
                    the final memory after the system runs""")

    window2 = ctk.CTkToplevel(window)
    ctk.set_appearance_mode(place['window']['mode'])
    ctk.set_default_color_theme(place['window']['color'])
    window2.title('UVSIM')

    canvas2 = ctk.CTkCanvas(window2)
    canvas2.configure(bg=place['window']['background'])

    canvas3 = ctk.CTkCanvas(window2)
    canvas3.configure(bg=place['window']['background'])

    mem = Memory()
    mem_editor = MemoryEditor(mem)
    mem_editor.read_file(path, mem)

    editor_label = ctk.CTkLabel(canvas2, text=place['editor_label']['text'])
    value_label = ctk.CTkLabel(canvas2, text=place['value_label']['text'])
    pos_label = ctk.CTkLabel(canvas2, text=place['pos_label']['text'])
    cur_mem_label = ctk.CTkLabel(canvas2, text=place['cur_mem_label']['text'])
    insert_btn = ctk.CTkButton(canvas2, text=place['insert_btn']['text'], command=mem_insert)
    del_btn = ctk.CTkButton(canvas2, text=place['del_btn']['text'], command=mem_delete)
    cpy_btn = ctk.CTkButton(canvas2, text=place['cpy_btn']['text'], command=mem_copy)
    cut_btn = ctk.CTkButton(canvas2, text=place['cut_btn']['text'], command=mem_cut)
    paste_btn = ctk.CTkButton(canvas2, text=place['paste_btn']['text'], command=mem_paste)
    save_btn=ctk.CTkButton(canvas2, text=place['save_btn']['text'], command=save_memory)
    run_btn = ctk.CTkButton(canvas2, text=place['run_btn']['text'], command=run)
    help_btn=ctk.CTkButton(canvas2, text=place['help_btn']['text'], command=edit_help)
    value_entry=ctk.CTkEntry(canvas2)
    pos_entry=ctk.CTkEntry(canvas2)
    edit_mem_textbox=ctk.CTkTextbox(canvas2, height=500, width=250)
    scrollbar = ctk.CTkScrollbar(canvas2)
    editor_label.grid(**place['editor_label']['grid'])
    value_label.grid(**place['value_label']['grid'])
    pos_label.grid(**place['pos_label']['grid'])
    cur_mem_label.grid(**place['cur_mem_label']['grid'])
    insert_btn.grid(**place['insert_btn']['grid'])
    del_btn.grid(**place['del_btn']['grid'])
    cpy_btn.grid(**place['cpy_btn']['grid'])
    cut_btn.grid(**place['cut_btn']['grid'])
    paste_btn.grid(**place['paste_btn']['grid'])
    save_btn.grid(**place['save_btn']['grid'])
    run_btn.grid(**place['run_btn']['grid'])
    help_btn.grid(**place['help_btn']['grid'])
    value_entry.grid(**place['value_entry']['grid'])
    pos_entry.grid(**place['pos_entry']['grid'])
    edit_mem_textbox.grid(**place['edit_mem_textbox']['grid'])
    scrollbar.grid(**place['scrollbar']['grid'])
    edit_mem_textbox.configure(yscrollcommand=scrollbar.set)
    scrollbar.configure(command=edit_mem_textbox.yview)
    results_label = ctk.CTkLabel(canvas3, text=place['results_label']['text'])
    ops_traceback_label = ctk.CTkLabel(canvas3, text=place['ops_traceback_label']['text'])
    final_mem_label = ctk.CTkLabel(canvas3, text=place['final_mem_label']['text'])
    entry_help_btn = ctk.CTkButton(canvas3, text=place['entry_help_btn']['text'], command=run_help)
    final_mem = ctk.CTkTextbox(canvas3, height=10, width=5)
    run_results = ctk.CTkTextbox(canvas3, height=10, width=5)
    final_mem.grid(**place['final_mem']['grid'])
    results_label.grid(**place['results_label']['grid'])
    ops_traceback_label.grid(**place['ops_traceback_label']['grid'])
    final_mem_label.grid(**place['final_mem_label']['grid'])
    entry_help_btn.grid(**place['entry_help_btn']['grid'])
    run_results.grid(**place['run_results']['grid'])

    update_memory()
    canvas2.grid()


def main():
    place = get_json()
    window = ctk.CTk()
    ctk.set_appearance_mode(place['window']['mode'])
    ctk.set_default_color_theme(place['window']['color'])
    window.title('UVSIM')
    canvas1 = ctk.CTkCanvas(window)
    canvas1.configure(bg=place['window']['background'])
    global go_to_editor
    path = ''
    
    def get_filepath():
        '''
        Triggers when open file button is pressed
        Opens a file dialogue and retrieves the filepath of a text file
        '''
        nonlocal path
        path = fd.askopenfilename(filetypes=[('Text Files', '*.txt')])
        filepath_lbl.configure(text=path)
        if path != '':
            con_editor_btn.grid(**place['con_editor_btn']['grid'])   

    def go_to_editor():
        '''
        Starts another process with the filepath to run
        '''
        nonlocal path
        show_window(window, path)

    welcome_label = ctk.CTkLabel(canvas1, text=place['welcome_label']['text'])
    filepath_lbl = ctk.CTkLabel(canvas1, text=place['filepath_lbl']['text'])
    filepath_btn = ctk.CTkButton(canvas1, text=place['filepath_btn']['text'], command=get_filepath)
    con_editor_btn = ctk.CTkButton(canvas1, text=place['con_editor_btn']['text'], command=go_to_editor)
    welcome_label.grid(**place['welcome_label']['grid'])
    filepath_lbl.grid(**place['filepath_lbl']['grid'])
    filepath_btn.grid(**place['filepath_btn']['grid'])

    canvas1.grid()
    window.mainloop()

if __name__ == "__main__":
    main()
